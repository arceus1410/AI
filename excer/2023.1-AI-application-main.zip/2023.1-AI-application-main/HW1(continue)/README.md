# ASSIGNMENT WEEK 10  
run file my_code.py hoặc my_code.ipynb
