# AI application assignment


